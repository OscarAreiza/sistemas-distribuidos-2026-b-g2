# LMS Library — Release v3.0.0

## What's in this release

A microservices architecture, one repository per bounded context, fronted by a single gateway:

- **`lms-api-gateway`** (nginx) — single entry point, path-based routing, rate limiting, and a
  cheap `Authorization`-header presence check. Real JWT validation always happens inside each
  service, never at the gateway (`ADR-003`, `ADR-007`).
- **4 domain APIs**: `lms-access-api` (Node.js/Express, `ADR-011` — authenticates the
  Administrator, issues RS256 sessions), `lms-membership-api`, `lms-catalog-api`,
  `lms-circulation-api` (Go, hexagonal architecture).
- **`lms-iam`** — role/permission decisions for Administrators (`ADR-012`). Exposes
  `GET /api/v1/iam/authorize`.
- **`lms-workflow`** — the overdue-loan penalty saga (`ADR-008`): detects overdue loans, marks
  them late, suspends the student, with forward-recovery and idempotency per `loan_id`.
- **`lms-worker`** — the scheduled-jobs service (`ADR-009`): due-date notices, fines accrual,
  catalog reindexing. Stateless, no database.
- **`lms-front`** — the Module Federation shell, composing 4 domain portals (3 in React, Access in
  Vue 3 per `ADR-011`'s documented exception).
- **Shared data layer (Anexo J)** — one PostgreSQL instance (`lms-infra-postgres`) with one schema
  per domain (`access`, `membership`, `catalog`, `iam`, `workflow`), one MongoDB instance
  (`lms-infra-mongo`) for `loan_db`. Every service connects with its own least-privilege app role
  (`*_app`), never the instance administrator.

## What's new since v2.0.1

- The gateway went from "repo exists, empty README" to a real, merged implementation.
- `lms-iam`, `lms-workflow`, `lms-worker` went from empty repos to real, hexagonal Go services.
- Three previously-missing internal routes were added: `lms-circulation-api`'s
  `POST /loans/{id}/mark-late` and `POST /loans/{id}/notify`, `lms-catalog-api`'s
  `POST /books/reindex` — closing the gap between what `lms-workflow`/`lms-worker` call and what
  actually existed.
- `lms-catalog-api` now enforces a real `RequirePermission` check (via `lms-iam`) on
  `POST/PATCH/DELETE /books`, closing part of the highest-ranked finding in this project's STRIDE
  review (`05-architecture/security/stride-MENESESLUIS-bot.md`).
- The one-click local installer now provisions all of the above, not just the original 4
  domain APIs.

## Known gaps — read before relying on this release

- **`lms-iam`'s `/authorize` endpoint is not called by anything yet.** The service exists and
  answers correctly, but no other service's middleware calls it — authorization is still
  "has a valid token," not "is this role allowed to do this." `ADR-012`'s default (no role
  assignment = full `ADMINISTRATOR` access) means this is safe, just not yet enforcing anything.
- **`lms-infra-postgres` PR #14** (adding the `access_app`/`workflow_app`/`iam_app` database
  roles and wiring their migration executors into the shared instance) is open, reviewed, not yet
  merged. Until it merges, `lms-access-api`, `lms-workflow`, and `lms-iam` cannot reach the
  database on a freshly-provisioned instance.
- **`mark-late`/`notify`/`accrue-fines`/`reindex`** were added without a Go toolchain available to
  run `go build`/`go vet`/`go test` locally — they are syntactically written against each
  service's existing patterns but unverified by tooling; rely on CI or a local Go run before
  trusting them in production.
- **`accrue-fines`** is a deliberate no-op stub — no fine-calculation domain model exists yet in
  `02-domain/entities-and-rules.md`. The route exists so `lms-worker` doesn't 404; it does not
  compute or apply any fine.
- **No TLS anywhere** — the gateway serves plain HTTP. See `05-architecture/security-threat-model.md`
  for the full, current threat model and its open items.
- **Each `-api`'s own direct host port is still published** alongside the gateway in the local
  pod (`8081`–`8085`) — a client that knows the port can bypass the gateway's rate limiting and
  auth-header check entirely. Tracked as an open item in the threat model (T3/SEC-01).

## Installing it

See `README.md` in this same folder. Short version: run `lms-installer.exe` on a Windows machine
with Docker Desktop already running — it clones every repo, provisions the shared databases, and
brings up the full stack.
