# LMS Library — local installer

`lms-installer.exe` is a one-click Windows installer that stands up the full local stack on a
teammate's machine: clones every repo it needs, brings up the shared Docker network and the two
database instances, builds and starts the pod (4 domain APIs, `lms-iam`, `lms-workflow`,
`lms-worker`, 4 portals, the shell, the gateway), waits for it to answer, opens the browser, and
leaves a `LMS Library.url` shortcut on the Desktop pointing at `http://localhost/` — so the next
time, it's just a double-click on that shortcut, not the installer again.

## What it actually does

1. Checks `git` and `docker` are on `PATH` (Docker Desktop must already be installed and running
   — this installer does not install Docker itself).
2. Clones (or `git pull`s, if already present) into `%USERPROFILE%\lms-library\`:
   `lms-membership-db`, `lms-catalog-db`, `lms-circulation-db`, `lms-infra-postgres`,
   `lms-infra-mongo`, `lms-access-api`, `lms-membership-api`, `lms-catalog-api`,
   `lms-circulation-api`, `lms-front`, `lms-membership-portal`, `lms-catalog-portal`,
   `lms-circulation-portal`, `lms-access-portal`, `lms-api-gateway`, `lms-iam`, `lms-workflow`,
   `lms-worker` — all from `github.com/code-corhuila`.
3. Writes `lms-pod/compose.yml` and its `env/*.env` files from scratch — `lms-pod` is a
   local-only assembly, never pushed to GitHub (see `local-setup.md`), so the installer embeds
   the exact same content this project's own sandbox built and ran it with.
4. Writes `lms-infra-postgres/env/dev.env` and `lms-infra-mongo/env/dev.env` from each repo's own
   `*.env.example`, with the placeholder passwords filled in with simple dev-only values.
   Generates `lms-infra-mongo/mongo/keyfile` (required for Mongo's single-node replica set,
   `rules/2-anexos/B-db-mongo.md` rule 6) with Node's own `crypto.randomBytes` — no `openssl`
   dependency.
5. `docker network create platform` (the shared network every service and both databases need —
   ignored if it already exists).
6. Brings up `lms-infra-postgres`, then `lms-infra-mongo`, then `lms-pod` (`docker compose up -d
   --build`, in that order — the pod's services need both databases reachable by name).
7. Polls `http://localhost/health` for up to 5 minutes, then opens the default browser at
   `http://localhost/` and writes the Desktop shortcut.

## Honesty notes — read before relying on this

This was built and compiled in a Linux sandbox with **no Windows machine and no Docker Desktop
available** to run it end to end. What was actually verified:

- The `.exe` is a real, valid Windows PE binary (checked its `MZ` header directly), cross-compiled
  with `pkg` (`node18-win-x64`) from `install-lms.cjs` — not assumed, not simulated.
- Every repo name, `compose.yml` content, env var name, and the Mongo keyfile requirement were
  read directly from the real sibling repos in this project (`lms-pod/compose.yml`,
  `lms-infra-postgres/compose.yml`, `lms-infra-mongo/compose.yml` and their `env/*.env.example`
  files) — not guessed from memory.

- `lms-iam`/`lms-workflow` connect to the shared PostgreSQL instance as `iam_app`/`workflow_app` —
  these roles only exist once `lms-infra-postgres` PR #14 (consolidating the roles/compose-wiring
  work) is merged to `develop`. Until then, those two containers will fail to start against a
  freshly-cloned `lms-infra-postgres`.

What was **not** verified, because this sandbox cannot:

- That it actually runs end to end on a real Windows machine with Docker Desktop.
- That the generated Mongo keyfile's permissions survive a Windows-to-container bind mount the
  way they do on Linux (`chmod 400` is best-effort here; Docker Desktop's volume translation on
  Windows is the one part of this flow with no Linux equivalent to test against).
- That `docker compose --env-file env/dev.env -f compose.yml up -d --build` for
  `lms-infra-postgres`/`lms-infra-mongo` resolves their own `include:` paths correctly when
  invoked exactly this way (it was written to match their documented usage in each repo's own
  `env/*.env.example` comment, not run).

**First real run should be watched, not assumed silent.** If something in this list turns out
wrong, `install-lms.cjs` is the source of truth to fix — rebuild with:

```bash
npm install --no-save pkg
npx pkg install-lms.cjs --targets node18-win-x64 --output lms-installer.exe
```

## Uninstall / reset

Nothing here touches the registry or installs anything outside `%USERPROFILE%\lms-library\` and
one Desktop shortcut. To tear down: `docker compose down -v` in each of `lms-pod`,
`lms-infra-postgres`, `lms-infra-mongo`, then delete `%USERPROFILE%\lms-library\` and the
Desktop shortcut.
